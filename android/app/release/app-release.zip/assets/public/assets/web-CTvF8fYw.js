import{W as n}from"./index-Cr_jX7sK.js";import"./index-DF8yQjpR.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
